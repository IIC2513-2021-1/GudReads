const KoaRouter = require('koa-router');
const pkg = require('../../package.json');

const router = new KoaRouter();

router.get('home','/', async (ctx) => {
  await ctx.render('index', {
    appVersion: pkg.version,
    authorsPath: ctx.router.url('authors.list'),
    newBookPath: ctx.router.url('books.new'),
    newSessionPath: ctx.router.url('session.new'),
    
  });
});

module.exports = router;
