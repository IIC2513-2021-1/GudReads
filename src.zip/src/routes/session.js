const KoaRouter = require('koa-router');
//const bcrypt = require('bcrypt');

const router = new KoaRouter();
/////////////////////////////////////////////////
//PARTE 1
/////////////////////////////////////////////////
//1.1
//router.get('session.new', '/new', (ctx) => ctx.render('session/new'));

//1.2
// router.post('session.create', '/', async (ctx) => {
//   const { email, password } = ctx.request.body;
//   const user = await ctx.orm.user.findOne({ where: { email } });
//1.3
       ///////////////////////////////////////////////////////////////
//     //COMENTAR: En la vida real la contraseña no está guardada "tal cual" en la db, en otra cápsula aprenderemos 
//     //a encriptar esta contraseña para almacenarla correctamente.
       ///////////////////////////////////////////////////////////////
//   const authenticated = user && password === user.password;
//   if (user && authenticated) {
//1.4
       ///////////////////////////////////////////////////////////////
//     //COMENTAR: Les proponemos que investiguen una forma de trabajar con el id para no exponerlo directamenre en
       //las cookies
       ///////////////////////////////////////////////////////////////
//     ctx.session.currentUserId = user.id;
//     ctx.redirect('/');
//   } else{
//1.5
//     await ctx.render('session/new', {
//       email,
//       error: 'Correo o contraseña incorrecta',
//     });    
//   }
// });

/////////////////////////////////////////////////
//PARTE 2
/////////////////////////////////////////////////
router.get('session.new', '/new', (ctx) => ctx.render('session/new', {
//2.1
  submitPath: ctx.router.url('session.create'),
  notice: ctx.flashMessage.notice,
}));

router.post('session.create', '/', async (ctx) => {
  const { email, password } = ctx.request.body;
  const user = await ctx.orm.user.findOne({ where: { email } });
  const authenticated = user && password === user.password;
  if (user && authenticated) {
    ctx.session.currentUserId = user.id;
    ctx.redirect('/');
  } else{
    await ctx.render('session/new', {
      email,
  //2.1
      submitPath: ctx.router.url('session.create'),
      error: 'Correo o contraseña incorrecta',
    });    
  }
});

/////////////////////////////////////////////////
//PARTE 3
/////////////////////////////////////////////////
//3.3
router.delete('session.destroy', '/', (ctx) => {
  ctx.session.currentUserId = null;
  ctx.redirect('/');
});

// PARECE QUE NO SE USA 
// router.get('session.created', '/created', (ctx) => ctx.render('session/success', {
//   createSessionPath: ctx.router.url('session.create'),
//   notice: ctx.flashMessage.notice,
// }));

module.exports = router;