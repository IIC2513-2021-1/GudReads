import './assets';
import '../styles/index.scss';

// eslint-disable-next-line no-console
console.log('App is running on the browser too!');
