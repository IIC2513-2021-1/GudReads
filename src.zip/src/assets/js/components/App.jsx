import React from 'react';
import { hot } from 'react-hot-loader';

function App() {
  return <div>Hello React World!</div>;
}

export default hot(module)(App);
