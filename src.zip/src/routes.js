const KoaRouter = require('koa-router');

const hello = require('./routes/hello');
const index = require('./routes/index');
const authors = require('./routes/authors');
const books = require('./routes/books');
const booksForAuthors = require('./routes/booksForAuthors');
/////////////////////////////////////////////////
//PARTE 1
/////////////////////////////////////////////////
//1.1
const session = require('./routes/session');

const users = require('./routes/users');
const router = new KoaRouter();

/////////////////////////////////////////////////
//PARTE 3
/////////////////////////////////////////////////
//3.1
router.use(async(ctx,next)=>{
  if (ctx.session.currentUserId){
    ctx.state.currentUser = await ctx.orm.user.findByPk(ctx.session.currentUserId);
  }
  return next();
});

//3.3
router.use(async (ctx, next) => {
  Object.assign(ctx.state, {
    paths: {
      destroySession: ctx.router.url('session.destroy'),
      
      //3.4 
      newSession: ctx.router.url('session.new'),

    },
  });
  return next();
});




router.use('/', index.routes());
router.use('/hello', hello.routes());
router.use('/authors', authors.routes());
router.use('/books', books.routes());
router.use('/users', users.routes());
router.use('/authors/:authorId/books', booksForAuthors.routes());

/////////////////////////////////////////////////
//PARTE 1
/////////////////////////////////////////////////
//1.1
router.use('/session', session.routes());


module.exports = router;

